import { useState, useEffect } from "react";
//import { realtime } from "../../../react14-realtime/src/realtimeConfig";
import { ref, onValue } from "firebase/database";
import Navi from "./Navi";

function Listener(){
  
}
